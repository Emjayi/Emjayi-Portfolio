module.exports = {
	output: "standalone",
};
